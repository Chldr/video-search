video_detail.js
