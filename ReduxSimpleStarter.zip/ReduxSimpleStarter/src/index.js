import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import YTSearch from 'youtube-api-search';

import SearchBar from './components/search_bar';

const API_KEY = 'AIzaSyC-yIB2mVWBBzCp78dKvr5vve3VALd8bRo';

YTSearch = ({key: API_KEY, term: 'surfboard'}, function(data) {
    console.log(data);
});

// Create an component. This component is going to produce some HTML.

const APP= () => {
    return (
        <div>
            <SearchBar />
        </div>
    );
    
}



ReactDOM.render(<APP />, document.querySelector('.container'));
